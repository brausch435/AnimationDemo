import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Jumper;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Location;

public class JumperRunnerForSit4{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Jumper j = new Jumper();
        ActorWorld world = new ActorWorld();
        world.add(new Location(4,9),j);
        j.setDirection(90);
        world.add(new Rock());
        world.show();
	}

}
