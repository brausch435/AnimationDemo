import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Jumper;
import info.gridworld.actor.Rock;

public class JumperRunnerForSit3 {

	public static void main(String[] args) {
		
		ActorWorld world2 = new ActorWorld();
		
		
		
		world2.add(new Jumper());
		world2.add(new Rock());
		world2.show();
	}

	
}
