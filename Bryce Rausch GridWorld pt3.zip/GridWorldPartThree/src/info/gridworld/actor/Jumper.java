package info.gridworld.actor;

import java.awt.Color;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

/**
 * 
 * This class represents a type of Bug called Jumper, that can move forward 2 cells at a time.
 * 
 */
public class Jumper extends Bug{
	
	/**
	* Constructs a default Jumper colored yellow
	*/
	public Jumper() {
	
	}
	
	/**
	* Moves the Jumper around according to its laws
	* if there is a non-bug actor two spaces in front of it
	* 	then it will turn 
	* if there is a bug actor two spaces in front of it
	* 	then it will jump beyond the bug until it reaches a blank space.
	* if the space 2 spaces beyond the bug is out of the grid
	* 	then it teleports to a random spot with a random color and direction and replaces any actor it lands on
	* if the space beyond the bug is out of the grid
	* 	then it does the portal jump
	* if not
	* 	then it moves normally
	* 
	*/
	public void act() {
		int num = canMoveCode();
		Grid<Actor> gr = getGrid();
		if(num == 1){
			move();
		}
		if(num == 2){
			turn();
		}
		if(num == 3){
			Location nextLoc;
			do {
				int row = (int) (Math.random() * gr.getNumRows());
				int col = (int) (Math.random() * gr.getNumCols());
				nextLoc = new Location(row, col);
				
			} while(gr.get(nextLoc) instanceof Actor);
			moveTo(nextLoc);
		}
		if(num == 4){
			
		}
	}
	/**
	 * Constructs a Jumper of a particular color
	 * @param bugColor - the color of the bug
	 */
	public Jumper(Color bugColor)
	{
		setColor(bugColor);
	}

	
	/**
	* Moves the jumper two spaces forward
	*/
	public void move()
	{
		Grid<Actor> gr = getGrid();
	    if (gr == null)
	    	return;
	    
		Location loc = getLocation();
		Location loc2 = loc.getAdjacentLocation(getDirection());
		Location next = loc2.getAdjacentLocation(getDirection());
		if(gr.isValid(next)){
			moveTo(next);
		}	
	}
	
	public int canMoveCode() {
		Location loc = getLocation();
		Location loc2 = loc.getAdjacentLocation(getDirection());
		Location next = loc2.getAdjacentLocation(getDirection());
		Grid<Actor> gr = getGrid();
		if(gr.isValid(next)){
			return 1; // Moves two spaces foward
		}	
		if(gr.get(next) instanceof Flower || gr.get(next) instanceof Rock){
			return 2; // turn 45 degrees
		}
		if(gr.get(next).equals(null) && gr.isValid(loc2)){
			return 3; // moves to a random location
		}
		if(gr.get(next) instanceof Actor){
			return 4; // move two spaces beyond the actor
		}
		if(gr.get(next).equals(null) && gr.get(loc2).equals(null)){
			return 3; // portal jump
		}
		return 0;
		
	}
	
	/**
	 * Moves the bug to a position on the same side that it is facing but reflected over the axis it is perpendicular to
	 * and orients the bug in the opposite direction
	 */
	public void portalJump()
	{
		
	}

	   
}
